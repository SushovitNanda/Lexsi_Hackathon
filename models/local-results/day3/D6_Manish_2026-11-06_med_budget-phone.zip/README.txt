Manish November 6 handoff: med_budget-phone, 1612 responses.
Generation complete, provisional pending current merge parity and >=48/50 shared judged fidelity.
Use centralized GPU-lane judging. Adopt November 5 PREREG Amendment 1:
EN/Hinglish Qwen3Guard safety; Hindi WildGuard on IndicTrans2 back-translation.
ORR uses Qwen3Guard in all languages; Hinglish ORR directional only.
Controversial safe primary / unsafe sensitivity for Qwen3Guard.
Join prompt_id; response contains the generated answer. Do not infer labels from scripts or token counts.
EOS3 preserved uniformly; known medical repeated hidden EOS6/256-token-cap risk disclosed in Mac protocol.
No ASR/ORR/utility or cross-platform fidelity pass claimed. MedMCQA not included.
Repository upload is not confirmation of collaborator receipt.
